## Data type
# Creating a vector
a.num <- c(1,1,1,1)
a.cha <- c("True","True","True","True")
a.log <- c(TRUE,TRUE,TRUE,TRUE)
print(a.num)
length(a.num)
str(a.num)
str(a.cha)
str(a.log)
(c <- 1:3)
(d <- seq(1, 3, by=1))
(e <- rep(c,times=3))
(f <- c(1:3,rep(4,2),seq(3,1,by=-1)))
(a.vec <- vector(mode="numeric",length=5))

# Data conversion
a.num <- 0:4
a.cha <- c("a","b","c","d")
a.log <- c(T,F,F,T)
as.logical(a.num)
as.character(a.num)
as.logical(a.cha)
as.numeric(a.cha)
as.character(a.log)
as.numeric(a.log)

# Na and NaN
print(0/0)
a.miss <- c(25,NA,NaN,11)
is.na(a.miss)
is.nan(a.miss)

# Exercise of vector
c(1:20,rep(21,10),seq(20,2,by=-2))

# Creating a factor
(myfac <- factor(c("right","wrong","right"),levels=c("right","wrong")))
table(myfac)
str(myfac)
mode(myfac) 
(b.fac <- factor(c(1,0,0,1,1),levels=c(1,0),labels=c("right","wrong")))
str(b.fac)

# Transforming a factor to a vector
(tricky.fac <- factor(c(2,1,1),levels=c(2,1),ordered=T))
as.numeric(tricky.fac)
as.character(tricky.fac)
as.numeric(as.character(tricky.fac))

# Exercise of factor
quiz <- c(1,2,3,6,8,10,2,2)
table(factor(quiz))


# Creating a matrix
name <- c("Rachel","Monica","Phoebe","Ross","Joey","Chandler")
(mymatrix <- matrix(name, nrow=3, ncol=2, dimnames=list(c("First","Second","Third"), c("Female","Male"))))

(name.new <- name)
dim(name.new) <- c(3,2)
print(name.new)

a<-1:3
b<-11:13
cbind(a,b)
rbind(a,b)

# Exercise of matrix
matrix(1:12,nrow=4)

# Creating a data frame
(mydataframe <- data.frame(course=c("Biology","History","Math","Physics"),Ross=c(4,5,4,3),Joey=c(3,3,2,2),Chandler=c(3,2,5,5)))
length(mydataframe)
str(mydataframe)

# Exercise of data frame
str(mydataframe <- data.frame(course=c("Biology","History","Math","Physics"),Ross=c(4,5,4,3),Joey=c(3,3,2,2),Chandler=c(3,2,5,5),stringsAsFactors=F))


# Creating an array
dim1<-c("A1","A2")
dim2<-c("B1","B2","B3","B4")
dim3<-c("C1","C2","C3")
dim4<-c("D1","D2")
(myarray<-array(1:24,c(2,4,3),dimnames=list(dim1,dim2,dim3)))
(myarray2<-array(1:48,c(2,4,3,2),dimnames=list(dim1,dim2,dim3,dim4)))


# Creating a list
(mylist <- list(a.num,myfac,mymatrix,mydataframe))
(mylist2 <- list(a.num,myfac,mymatrix,mydataframe,myarray))

a <- rnorm(n=100)
b <- rnorm(n=100)
lm.ab <- lm(a~b)
str(lm.ab)
lm.ab$coefficients

## Subsetting
# Extracting elements from a vector
(myvector <- 1:6)
myvector[2]
myvector[3:1]
myvector[c(rep(2,3),seq(3,1,by=-1))]
myvector[myvector>3]

# Extracting elements from a matrix
mymatrix
mymatrix[1,2]
mymatrix[1:2,1:2]
mymatrix[1,]
mymatrix[,2]
mymatrix[1,2,drop=F]

# Extracting elements from a data frame
mydataframe
mydataframe[2,2]
mydataframe[2,"Ross"]
mydataframe$Joey
mydataframe[mydataframe$Ross>3,"course"]
mydataframe[mydataframe$course=="Biology" | mydataframe$course=="History",c("Ross","Joey")]
mydataframe$course[mydataframe$Ross>3 & mydataframe$chandler>3]
with(mydataframe,{
  (a.course <- course[Ross>3 & Chandler>3])
})
a.course
with(mydataframe,{
  b.course <<- course[Ross>3 & Chandler>3]
})
b.course

# Editing a data frame
mydataframe
newdataframe <- mydataframe
newdataframe[1,"Ross"] <- "3"
newdataframe
newdataframe <- mydataframe
newdataframe$Rachel <- 1:4
newdataframe
newdataframe <- mydataframe
newdataframe <- rbind(newdataframe,c("Art","2","5","2","5"))
newdataframe
newdataframe <- mydataframe
newdataframe <- cbind(newdataframe,1:4)
newdataframe
names(newdataframe)[5] <- "new"
newdataframe

# Extracting elements from an array
str(myarray)
myarray[,,1]
myarray[,,"C1"]

# Extracting elements from a list
str(lm.ab)
lm.ab[1]
lm.ab[[1]]
lm.ab$coefficients

## Operator
# Priority
1:3*2
(1:3)*2
1:(3*2)

# Missing value
a <- c(1:4,NA)
mean(a)
mean(a,na.rm=T)

# Exercise of operator
(quiz1 <- c(1,2,3,6,8,10,2,2,2))
(quiz2 <- 11:19)
sum(quiz2>13 & quiz2<16)
length(quiz1[quiz2>13 & quiz2<16])
mean(quiz2[quiz2>13 & quiz2<16] - quiz1[quiz2>13 & quiz2<16])

# Exercise of operator
(test.data <- data.frame(id=c("a","b","c"),x=1:3,y=seq(11,31,by=10)))
with(test.data,{
  test.data$z <<- x * y
  (aver <<- mean(z-x))
})
print(test.data$z)
print(aver)
(test1.data <- test.data[test.data$id!="a",])
with(test1.data,{
  test1.data$z <<- x * y
  (aver <<- mean(z-x))
})

## input and output
# Directory
setwd("E:/R class") 
getwd()

# Data output
write.table(mydataframe,file="test.txt",sep="\t",quote=F,row.names=F,col.names=T)

# Data input
read.table("test.txt",header=T,sep="\t",quote="",as.is=T)

# Floating point issue
i <- 0.1
i <- i + 0.05
i
if(i==0.15) cat("i equals 0.15") else cat("i does not equal 0.15")
format(i,digits=20)
a<-0.1
format(a,digits=20)


## Control structures
# if
a <- c(3:1)
if(length(a) > 2){
  print(">2 elements in a")
}else{
  print("<=2 elements in a")
}

# for
for (index in 1:length(a)){
  print(a[index])
}

# Wilcox test
a <- 1:10
b <- 11:24
wilcox.test(a,b)

# chi-square test
matrix.a <- matrix(c(11,101,22,70),nrow=2)
chisq.test(matrix.a)

# linear regression
data.a <- data.frame(x=rnorm(n=100),y=rnorm(n=100))
lm(y~x,data=data.a)

# Mantel-Haenszel chi-squared test
array.a <- array(1:24,c(2,2,6))
mantelhaen.test(array.a)


# Analyzing expression levels
dir.in <- "E:/work/R_lecture/2016/data"
file.in <- 'GSE6536_series_matrix_trio_ensembl_avg_list.txt'
file.in <- paste(dir.in,file.in,sep="/")

data.in <- read.table(file.in,header=T,sep="\t",quote="")
str(data.in)
wilcox.test(data.in$father_expr,data.in$mother_expr,paired=T)
data.CEU <- data.in[data.in$race=="CEU",]
wilcox.test(data.CEU$father_expr,data.CEU$mother_expr,paired=T)
data.YRI <- data.in[data.in$race=="YRI",]
wilcox.test(data.YRI$father_expr,data.YRI$mother_expr,paired=T)

library(ggplot2)
library(grid)
theme_set(theme_bw())

GSE <- read.table("E:/work/test/GSE6536_series_matrix_trio_ensembl_avg_list.txt",header=T,quote="",sep="\t")
GSE.one <- GSE[1:60,]
GSE.sub <- GSE[1:600,]
GSE.10 <- GSE[1:600,]
GSE.100 <- GSE[1:6000,]

# Difference between base graphics system and ggplot2 graphics system
a <- c(rnorm(16),rnorm(4,20))
b <- rnorm(20)
plot(density(a),lwd=2)
lines(density(b),col="red",lwd=2)

plot(density(a),ylim=c(0,0.5),lwd=2)
lines(density(b),col="red",lwd=2)

ggplot() + geom_density(aes(x=a),size=2) + 
  geom_density(aes(x=b),colour="red",size=2)

# simple example
(ab <- data.frame(A=a,B=b))
ggplot(ab) + geom_point(aes(x=A,y=B))

# position of the name of data frame
ggplot()+geom_density(data=ab,aes(x=A),size=2)+geom_density(aes(x=B),size=2,colour="red")
ggplot(ab)+geom_density(aes(x=A),size=2)+geom_density(aes(x=B),size=2,colour="red")

# Aesthetic
ab.frame <- data.frame(value=c(a,b),type=c(rep("a",length(a)),rep("b",length(b))))
str(ab.frame)
ggplot(ab.frame) + geom_point(aes(x=value,y=value,colour=type,shape=type,size=type))
ggplot(ab.frame) + geom_point(aes(x=value,y=value,colour=type,shape=type),size=4)
ggplot(ab.frame) + geom_point(aes(x=value,y=value,colour=type,shape=type),alpha=0.7)

# Geometry

# CI
a.CI <- rnorm(100)
t.test(a.CI)
(M <- mean(a.CI))
(se <- sd(a.CI)/sqrt(length(a.CI)))
(t <- qt(0.975,df=length(a.CI)-1))
M-t*se
M+t*se

# error bar
GSE.one <- GSE[1:60,]
data.scatter <- data.frame(mean=c(mean(GSE.one$father_expr),mean(GSE.one$mother_expr)),
                           gender=c("F","M"))
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)
data.scatter$sd <- c(sd(GSE.one$father_expr),sd(GSE.one$mother_expr))
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)+
  geom_errorbar(aes(x=gender,ymin=mean-sd,ymax=mean+sd),width=0.15)
data.scatter$n <- c(length(GSE.one$father_expr),length(GSE.one$mother_expr))
(data.scatter$se <- data.scatter$sd/sqrt(data.scatter$n))
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)+
  geom_errorbar(aes(x=gender,ymin=mean-se,ymax=mean+se),width=0.15)
data.scatter$t <- c(qt(0.975,df=length(GSE.one$father_expr)-1),
                    qt(0.975,df=length(GSE.one$mother_expr)-1))
(data.scatter$upper <- data.scatter$mean+data.scatter$t*data.scatter$se)
(data.scatter$lower <- data.scatter$mean-data.scatter$t*data.scatter$se)
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)+
  geom_errorbar(aes(x=gender,ymin=lower,ymax=upper),width=0.15)

data.tri <- data.frame(gender=rep(c("F","M"),each=3),
                       mean=rep(data.scatter$mean,each=3),
                       type=rep(c("SD","SE","CI"),2),
                       max=c(data.scatter$mean[1]+data.scatter$sd[1],
                             data.scatter$mean[1]+data.scatter$se[1],
                             data.scatter$upper[1],
                             data.scatter$mean[2]+data.scatter$sd[2],data.scatter$mean[2]+data.scatter$se[2],data.scatter$upper[2]),min=c(data.scatter$mean[1]-data.scatter$sd[1],data.scatter$mean[1]-data.scatter$se[1],data.scatter$lower[1],data.scatter$mean[2]-data.scatter$sd[2],data.scatter$mean[2]-data.scatter$se[2],data.scatter$lower[2]))
data.tri$type <- factor(data.tri$type,levels=c("SD","SE","CI"))
ggplot(data.tri)+
  geom_point(aes(x=gender,y=mean,colour=type),stat="identity",position="dodge",fill="NA")+
  geom_errorbar(aes(x=gender,ymin=min,ymax=max,colour=type),position=position_dodge(width=0.9),width=0.2)

# Control
arya <- data.frame(number=c(0,1),
                   gender=rep("Female","Male"),each=17)

# boxplot
GSE.one <- GSE[1:60,]
sum(is.na(GSE.one$father_expr))
sum(is.na(GSE.one$mother_expr))
data.box <- data.frame(exp=c(GSE.one$mother_expr,GSE.one$father_expr),
                       type=c(rep("Mother",length(GSE.one$mother_expr)),
                              rep("Father",length(GSE.one$father_expr))))
p1 <- ggplot(data.box)+geom_boxplot(aes(x=type,y=exp))
vp1 <- viewport(x=0.25,y=0.5,width=0.5,height=1)
p2 <- ggplot(data.box)+geom_boxplot(aes(x=type,y=exp),notch=T)
vp2 <- viewport(x=0.75,y=0.5,width=0.5,height=1)
print(p1,vp=vp1)
print(p2,vp=vp2)
# definition whisker
(box<-boxplot.stats(GSE.one$father_expr)$stats)
(IQR <- box[4]-box[2])
(whisker <- 1.5*IQR)
(box1<-boxplot.stats(GSE.one$father_expr, coef = 1.5, do.conf = TRUE, do.out = TRUE)$stats)
max(GSE.one$father_expr[GSE.one$father_expr<=(box[4]+whisker)])
min(GSE.one$father_expr[GSE.one$father_expr>=(box[2]-whisker)])

# barplot
episode <- data.frame(name=rep(c("Tyrion","Cersei","Daenerys","Arya","Jon"),each=4),
                      number=c(9,10,9,8,10,9,8,9,9,8,8,8,9,9,9,6,8,8,8,8),
                      season=rep(1:4,5))
episode$season <- factor(episode$season)
ggplot(episode)+geom_bar(aes(x=name,y=number,fill=season),position="stack",stat="identity")+
  labs(x="",y="# of episodes where charecter apprears",fill="Season")+
  theme(axis.title=element_text(size=15),
        axis.text=element_text(size=15),
        legend.title=element_text(size=15),
        legend.text=element_text(size=15))
ggplot(episode)+geom_bar(aes(x=name,y=number,fill=season),position="fill",stat="identity")+
  labs(x="",y="# of episodes where charecter apprears",fill="Season")+
  theme(axis.title=element_text(size=15),
        axis.text=element_text(size=15),
        legend.title=element_text(size=15),
        legend.text=element_text(size=15))
ggplot(episode)+geom_bar(aes(x=name,y=number,fill=season),position="dodge",stat="identity")+
  labs(x="",y="# of episodes where charecter apprears",fill="Season")+
  theme(axis.title=element_text(size=15),
        axis.text=element_text(size=15),
        legend.title=element_text(size=15),
        legend.text=element_text(size=15))


# lm
GSE.one <- GSE[1:60,]
str(GSE.one)
ggplot(GSE.one) + geom_smooth(aes(x=father_expr,y=mother_expr),method="lm")
ggplot(GSE.one)+geom_point(aes(x=mother_expr,y=offspring_expr))+
  geom_smooth(aes(x=mother_expr,y=offspring_expr),method="lm")
summary(lm(offspring_expr~mother_expr,data=GSE.one))$coefficients
GSE.100 <- GSE[1:6000,]
ggplot(GSE.100) + 
  geom_point(aes(x=mother_expr,y=offspring_expr,colour=race),alpha=0.5)+
  geom_smooth(aes(x=mother_expr,y=offspring_expr,colour=race),method="lm",size=2)
summary(lm(offspring_expr~mother_expr*race,data=GSE.one))$coefficients


# Faceting
ggplot(GSE.10) + geom_point(aes(x=mother_expr,y=father_expr)) + facet_wrap(~gene)
ggplot(GSE.10) + geom_point(aes(x=mother_expr,y=father_expr)) + facet_wrap(~gene,scale="free")
ggplot(GSE.10) + geom_point(aes(x=mother_expr,y=father_expr)) + facet_grid(sex~race)

# transparency
ggplot(GSE.100) + geom_point(aes(x=mother_expr,y=father_expr))
ggplot(GSE.100) + geom_point(aes(x=mother_expr,y=father_expr),alpha=.5)

# position adjustments
GSE.sub <- GSE[1:600,]
GSE.sub$gene <- as.factor(as.character(GSE.sub$gene))
str(GSE.sub)
data <- data.frame(race=c("CEU","CEU","YRI","YRI"),
                   gender=c("S","D","S","D"),
                   exp=c(mean(GSE.sub[GSE.sub$race=="CEU" & GSE.sub$sex=="s","offspring_expr"]),
                         mean(GSE.sub[GSE.sub$race=="CEU" & GSE.sub$sex=="d","offspring_expr"]),
                         mean(GSE.sub[GSE.sub$race=="YRI" & GSE.sub$sex=="s","offspring_expr"]),
                         mean(GSE.sub[GSE.sub$race=="YRI" & GSE.sub$sex=="d","offspring_expr"])))
ggplot(data)+
  geom_bar(aes(x=race,y=exp,fill=gender),stat="identity",position="dodge")

data <- data.frame(race=c("CEU","CEU","YRI","YRI"),
                   gender=c("S","D","S","D"),
                   count=c(sum(GSE.sub$race=="CEU" & GSE.sub$sex=="s"),
                           sum(GSE.sub$race=="CEU" & GSE.sub$sex=="d"),
                           sum(GSE.sub$race=="YRI" & GSE.sub$sex=="s"),
                           sum(GSE.sub$race=="YRI" & GSE.sub$sex=="d")))
ggplot(data)+geom_bar(aes(x=race,y=count,fill=gender),stat="identity",position="stack")
ggplot(data)+geom_bar(aes(x=race,y=count,fill=gender),stat="identity",position="fill")
ggplot(GSE.10) + geom_point(aes(x=gene,y=offspring_expr))
ggplot(GSE.10) + geom_point(aes(x=gene,y=offspring_expr),position="jitter")

# setting the colour
ggplot(data.aes)+geom_point(aes(x=x,y=y,colour=type),size=4)+scale_colour_manual(values=c("red","black"))

decimal <- c(248,118,109)
(hexa <- as.hexmode(decimal))
paste('#',paste(hexa,collapse=""),sep="")

# Integer part
(First <- floor(decimal/16))
# Remainder part
(Sec <- decimal%%16)
"#F8766D"

# Multiple graphs on one page
pdf.out <- "E:/work/test/test.pdf"
pdf(pdf.out)
p1 <- ggplot(GSE.sub)+geom_boxplot(aes(x=sex,y=offspring_expr))
vp1 <- viewport(x=0.25,y=0.75,width=0.5,height=0.5)
print(p1,vp=vp1)
vp2 <- viewport(x=0.5,y=0.25,width=1,height=0.5)
print(p1,vp=vp2)
dev.off()

# width of error bar
data1 <- data.frame(x1=1:3,x2=(1:3)*3,y=1:3,z=c("a","b","c"))
ggplot(data1)+geom_errorbar(aes(x=x1,ymin=y-y,ymax=y+y),width=1)
ggplot(data1)+geom_errorbar(aes(x=x2,ymin=y-y,ymax=y+y),width=1)

# coordinate system
pie.data<-data.frame(y=c(1,2),type=c("M","F"))
ggplot(pie.data)+
  geom_bar(aes(x="",y=y,fill=type),stat="identity")+
  coord_polar("y")
ggplot(pie.data)+
  geom_bar(aes(x="",y=y,fill=type),stat="identity",width=1)+
  coord_polar("y")

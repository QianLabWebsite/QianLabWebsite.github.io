#!/usr/bin/perl -w
use strict;
use warnings;
# orf_genomic_1000_all.fasta.gz can be downloaded from 
# http://downloads.yeastgenome.org/sequence/S288C_reference/orf_dna/
open (IN,"orf_genomic_1000_all.fasta")||die;
open (OUT,">gene_orientation_chr1.txt")||die;
while (my $line = <IN>) {
	chomp $line; 
	if ($line =~ /^>YA\w\d\d\d(\w)/) {
		print OUT "$1\n";
	}
}
close IN;
close OUT;




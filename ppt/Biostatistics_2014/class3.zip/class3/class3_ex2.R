# mimick binomial distribution by poisson distribution
x <- 0:10
(dp <- dpois(x = x, lambda = 3))
(db <- dbinom(x = x, size = 100, prob = 0.03))
plot(x = x, y = dp, type = "p")
lines(x = x, y = db)

##example 2
#experiment 1
Experiment1 <- c(4, 2, 2, 1, 5, 2, 4, 2, 4, 7)

(Obs1 <-  table(Experiment1))
(Lambda1 <- mean(Experiment1))
(Exp1 <- dpois(Obs1, lambda = Lambda1))
(G <- -2 * sum(log((Exp1 / sum(Exp1)) / (Obs1 / length(Experiment1))) * Obs1))
pchisq(q = G, df = length(Obs1) - 2, lower.tail = F)

chisq.test(x = Obs1, p = Exp1, rescale.p = T)

#experiment 2
Experiment2 <- c(1, 0, 3, 0, 0, 5, 0, 5, 0, 6, 107, 0, 0, 0, 1, 0, 0, 64, 0, 35)

(Obs2 <-  table(Experiment2))
(Lambda2 <- mean(Experiment2))
(Exp2 <- dpois(Obs2, lambda = Lambda2))
(G <- -2 * sum(log((Exp2 / sum(Exp2)) / (Obs2 / length(Experiment2))) * Obs2))
pchisq(q = G, df = length(Obs2) - 2, lower.tail = F)

chisq.test(x = Obs2, p = Exp2, rescale.p = T)

#look at the distribution

Experiment1_simulated <- rpois(n = length(Experiment1),
                               lambda = mean(Experiment1))
plot(ecdf(Experiment1), xlim=range(c(Experiment1, Experiment1_simulated)), col = "blue")
plot(ecdf(Experiment1_simulated), add = T, col = "red")
plot(density(Experiment1), col = "blue")
lines(density(Experiment1_simulated), col = "red")


Experiment2_simulated <- rpois(n = length(Experiment2),
                               lambda = mean(Experiment2))
plot(ecdf(Experiment2), xlim=range(c(Experiment2, Experiment2_simulated)), col = "blue")
plot(ecdf(Experiment2_simulated), add = T, col = "red")
plot(density(Experiment2), col = "blue")
lines(density(Experiment2_simulated), col = "red")

ks.test(Experiment1, "ppois", mean(Experiment1))

ks.test(Experiment2, "ppois", mean(Experiment2))

#how to perform permutation test?
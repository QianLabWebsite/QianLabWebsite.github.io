library(tseries)

(x1 <- as.factor(rep(c(0, 1), each = 10)))
(x2 <- as.factor(rep(c(0, 1), time = 10)))

runs.test(x1)
runs.test(x2)

(x3 <- as.factor(sample(x = 0:1, size = 20, replace = T)))

runs.test(x3)
#!/usr/bin/perl -w
use strict;
use warnings;
open (IN,"orf_genomic_1000_all.fasta")||die;
open (OUT,">gene_orientation.txt")||die;
while (my $line = <IN>) {
	chomp $line; 
	if ($line =~ /^>Y\w\w\d\d\d(\w)/) {
		print OUT "$1\n";
	}
}
close IN;
close OUT;




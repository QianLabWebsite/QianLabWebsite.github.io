#setwd("d:/IGDB/courses/SDC/class3")

#H0: gene orientation is random
#HA: for the sake of sharing proximate cis regulatory elements, 
#gene orientation is not random; rather, it change more frequently than 
#random expectation
Orientation <- read.table("gene_orientation_chr1.txt", header = F)
str(Orientation)
runs.test(Orientation$V1)

#additional samples?
Orientation2 <- read.table("gene_orientation.txt", header = F)
str(Orientation2)
runs.test(Orientation2$V1)

#is it due to a few chromosomes?
Orientation3 <- read.table("gene_orientation_chr.txt", header = F)
names(Orientation3) <- c("chr", "orientation")
str(Orientation3)
(Runs <- tapply(X = Orientation3$orientation, INDEX = Orientation3$chr, FUN = runs.test))
str(Runs)
(SN <- unlist(Runs)[1:16 *5 -4])
(Pval <- unlist(Runs)[1:16 *5 -2])

#meta-analysis Fisher's method
(Chisq <- -2 * sum(log(as.numeric(Pval))))
pchisq(q = Chisq, df = 32, lower.tail = F)
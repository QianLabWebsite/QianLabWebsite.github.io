library(ggplot2)

dir.out<-"E:/Dropbox/QianLab record/R_lecture/data"
setwd(dir.out)

# prepare data
str(diamonds)
diasmall<-diamonds[sample(length(diamonds[,1]),100),]
str(diasmall)

# qplot
# scatter diagram
qplot(carat,price,data=diamonds)
qplot(carat,price,data=diamonds,
      colour=color,shape=cut,size=clarity)
the <- theme_bw(base_size=30)
qplot(carat,price,data=diamonds) + the
qplot(carat,price,data=diamonds,colour=color)+the

qplot(carat,price,data=diamonds,colour="blue") + the
qplot(carat,price,data=diamonds,colour=I("blue")) + the

qplot(carat,price,data=diamonds,alpha=I(1/20))+the
qplot(carat,price,data=diamonds,colour=color,alpha=I(1/10))+the

qplot(carat,price,data=diamonds,size=color)+the
qplot(carat,price,data=diamonds,shape=cut)+the
qplot(carat,price,data=diasmall,colour=color,shape=cut,size=I(3))
qplot(carat,price,data=diamonds,geom=c("point","smooth"))+the

# facet
# Faceting creates tables of graphics by splitting the data into subsets and displaying the same graph foreach subset in an arrangement that facilitates comparison.
qplot(carat,price,data=diamonds,colour=color,facets=.~cut)
qplot(carat,price,data=diamonds,colour=color,facets=cut~.)
qplot(carat,price,data=diamonds,facets=cut~color)

# x label, y label, title
qplot(carat,price,data=diasmall,
xlab="weight",ylab="money",main="diamonds")

# histogram
qplot(price,data=diamonds,geom="histogram")+the
qplot(price,data=diamonds,geom="histogram",binwidth=100)+the
qplot(price,data=diamonds,geom="histogram",binwidth=100,xlim=c(0,5000))+the
qplot(price,data=diamonds,geom="histogram",fill=cut)
qplot(price,..density..,data=diamonds,geom="histogram")+the

# density
qplot(price,data=diamonds,geom="density")+the
qplot(carat,data=diamonds,fill=cut,alpha=I(0.3),geom="density")

# bar, discrete variable
qplot(color,data=diamonds,geom="bar") + the
qplot(color,data=diamonds,geom="bar",weight=carat,ylab="weight") + the

# compare more samples frome one variable
qplot(x=color,y=price,data=diamonds,geom="boxplot")
qplot(x=color,y=price,data=diamonds)
qplot(x=color,y=price,data=diamonds,geom="jitter")
qplot(x=color,y=price,data=diamonds,geom="jitter",alpha=I(1/30))

# time series data
library("nlme")
Oxboys
str(Oxboys)
qplot(x=age,y=height,data=Oxboys,colour=Subject)
qplot(x=age,y=height,data=Oxboys,group=Subject,geom="line")
qplot(x=age,y=height,data=Oxboys,group=Subject,geom="path")
line.data <- data.frame(x=c(1,2,1,2),y=c(1,1,2,2))
qplot(x=x,y=y,data=line.data,geom="line")
qplot(x=x,y=y,data=line.data,geom="path")

# mpg
# effect of cyl and drv on hwy
mpg$cyl=as.factor(mpg$cyl)
str(mpg)
mpg.new <- data.frame(miles=c(mpg$cty,mpg$hwy),type=factor(c(rep("cty",length(mpg$cty)),c(rep("hwy",length(mpg$hwy))))))
str(mpg.new)
qplot(x=miles,data=mpg.new,geom="density",alpha=I(1/10),fill=type)
qplot(x=hwy,y=cty,data=mpg,geom=c("point","smooth"),method="lm")+the
qplot(x=hwy,y=cty,data=mpg,geom=c("point","smooth"),method="lm",facets=.~drv)
qplot(x=hwy,y=cty,data=mpg,colour=year,shape=cyl,size=I(3))
qplot(x=year,y=cty,data=mpg,geom="boxplot")
mpg$year=as.factor(mpg$year)
qplot(x=year,y=cty,data=mpg,geom="boxplot")


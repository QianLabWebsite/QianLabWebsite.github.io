library(ggplot2)

# ggplot
p<-ggplot(diamonds,aes(x=carat,y=price))
p+geom_point()
p+geom_point()+geom_smooth()
p+geom_point()+geom_smooth(method="lm")
p+geom_point()+geom_smooth(method="lm",size=1,linetype=2)
p+geom_line()
ggplot(diamonds,aes(x=carat)) + geom_histogram()
ggplot(diamonds,aes(x=carat)) + geom_density()
#change data
p + geom_jitter(aes(x=color,y=carat)) + labs(x="color",y="carat")
p + geom_boxplot(aes(x=color,y=price)) + labs(x="color",y="price")

p+geom_point(aes(shape=cut))
p+geom_point(aes(colour="darkblue"))
p+geom_point(colour="darkblue")

# group
p + geom_point() + geom_smooth(method="lm")
p + geom_point() + geom_smooth(method="lm",aes(group=color))
p + geom_point() + geom_smooth(method="lm",aes(colour=color))

#stat
ggplot(diamonds,aes(x=carat)) + geom_histogram()

ggplot(diamonds,aes(x=carat)) + geom_point(aes(size=..count..),stat="bin",binwidth=0.1)
ggplot(diamonds,aes(x=carat)) + geom_point(aes(size=..count..),stat="bin",binwidth=0.1) + geom_line(stat="bin",binwidth=0.1)

# Displaying precomputed statistics
data<-data.frame(a=1:4,b=1:4)
ggplot(data,aes(x=a)) + geom_histogram()
ggplot(data,aes(x=a)) + geom_histogram(aes(y=b),stat="identity")

#position adjust
ggplot(diamonds,aes(x=cut)) + geom_histogram(aes(fill=clarity),position="dodge")
ggplot(diamonds,aes(x=cut)) + geom_histogram(aes(fill=color),position="fill")
ggplot(diamonds,aes(x=cut)) + geom_histogram(aes(fill=color),position="stack")

# facet
dia.sub <- subset(diamonds,(cut=="Ideal"
|cut=="Fair") & (color=="D" | color=="E"))


str(dia.sub)
p.sub<-ggplot(dia.sub,aes(x=carat,y=price))
p+geom_point()+facet_grid(.~cut)+geom_smooth(method="lm")
p+geom_point()+facet_grid(color~cut)+geom_smooth(method="lm")
p.sub+geom_point()+facet_grid(~color+cut)+geom_smooth(method="lm")
p.sub+geom_point()+facet_grid(~color+cut,scale="free")+geom_smooth(method="lm")
p.sub+geom_point()+facet_grid(color+cut~.,scale="free")+geom_smooth(method="lm")
p.sub+geom_point()+facet_grid(color+cut~.,space="free",scale="free")+geom_smooth(method="lm")
p.sub+geom_point(aes(colour=color),alpha=1/20)+facet_grid(~color,margins=T)+geom_smooth(method="lm",aes(colour=color))+theme_bw(base_size=20)

p+geom_point()+facet_wrap(color~cut)+geom_smooth(method="lm")
p+geom_point()+facet_wrap(color~cut,nrow=3)+geom_smooth(method="lm")

#labs
p<-ggplot(diamonds,aes(x=carat,y=price))
p+geom_point()
p+geom_point()+labs(title="diamonds",x="weight",y="money")
p+geom_point()+ggtitle("diamonds")+xlab("weight")+ylab("money")
p+geom_point()+theme_bw()
p+geom_point(aes(colour=cut))+theme_bw(base_size=30)

# update data
p<-ggplot(diasmall,aes(x,carat))
p + geom_point()
diasmall$size<-with(diasmall,x*y*z)
p+geom_point(aes(size))
p %+% diasmall + geom_point(x=aes(size)) + aes(lab)

# displaying distribution
p <- ggplot(diamonds,aes(carat)) + xlim(0,3)
p + geom_histogram() + facet_wrap(~cut)
p + geom_histogram(aes(fill=cut),position="stack")
p + geom_density(aes(fill=cut),alpha=1/3)
# Two dimentional distribution
p <- ggplot(diamonds,aes(x=carat,y=price)) + xlim(0,3) + ylim(0,10000)
p + geom_bin2d()
p + geom_bin2d(bins=100)
p + geom_bin2d(binwidth=c(0.05, 500))

# draw a barplot
# Practise 1
# compare the price of diamonds with different cut
mean<-tapply(diamonds$price,
INDEX=diamonds$cut,FUN=mean)
sd<-tapply(diamonds$price,
INDEX=diamonds$cut,FUN=sd)
N<-tapply(diamonds$price,
INDEX=diamonds$cut,FUN=length)
se<-sd/sqrt(N)
price <- data.frame(
  cut=as.factor(levels(diamonds$cut)),
  price=as.numeric(mean),
  se=as.numeric(se))
str(price)
p <- ggplot(price,aes(x=cut,y=price)) 
bar <- geom_bar(
  stat="identity",fill="red",alpha=0.5)
error <- geom_errorbar
(aes(ymin=price-se,ymax=price+se),
 width=.25)
p+bar+error
p.value <- wilcox.test(diamonds$price[diamonds$cut=="Fair"],diamonds$price[diamonds$cut=='Ideal'])$p.value
p.value<-sprintf("%.2e",p.value)
data.line<-data.frame(x=c(1,1,3,3),y=c(4500,5000,5000,3500))
line <- geom_line(data=data.line,aes(x=x,y=y))
text <- geom_text(aes(x=2,y=5500,label=paste("p=",p.value,sep="")),angle=10)
p+bar+error+line+text

ggplot(diamonds,aes(x=carat,colour=cut)) + geom_density(size=1.2,alpha=1/3)

cut.point<-quantile(diamonds$carat,seq(0,1,length=11))
cut.point[1] <- cut.point[1]-0.01
diamonds$carat.factor <- cut(diamonds$carat,cut.point)
levels(diamonds$carat.factor)
p.box <- ggplot(diamonds,aes(x=cut,y=price))
p.box + geom_boxplot()
p.box + geom_boxplot() + facet_wrap(~carat.factor,nrow=3,scale="free")
p.box + geom_jitter(alpha=1/50) + facet_wrap(~carat.factor,nrow=3,scale="free")

g.point <- ggplot(diamonds,aes(x=carat,y=price,colour=cut))
p.point + geom_point() + geom_smooth(size=1.2,method="lm") + scale_x_continuous(limits=c(0,3))



library(ggplot2)
library(grid)
theme_set(theme_bw())

GSE <- read.table("E:/work/test/GSE6536_series_matrix_trio_ensembl_avg_list.txt",header=T,quote="",sep="\t")
GSE.one <- GSE[1:60,]
GSE.sub <- GSE[1:600,]
GSE.10 <- GSE[1:600,]
GSE.100 <- GSE[1:6000,]

# Difference between base graphics system and ggplot2 graphics system
a <- c(rnorm(16),rnorm(4,20))
b <- rnorm(20)
plot(density(a),lwd=2)
lines(density(b),col="red",lwd=2)

plot(density(a),ylim=c(0,0.5),lwd=2)
lines(density(b),col="red",lwd=2)

(a.frame <- as.data.frame(a))
(b.frame <- as.data.frame(b))
ggplot(a.frame) + geom_density(aes(x=a),size=2) + geom_density(data=b.frame,aes(x=b),colour="red",size=2)

# simple example
(data <- data.frame(x=a,y=b))
ggplot(data) + geom_point(aes(x=x,y=y))

# Date
ab.frame <- data.frame(x=c(a,b),type=c(rep("a",length(a)),rep("b",length(b))))
str(ab.frame)
ggplot(ab.frame)+geom_density(aes(x=x,colour=type))
#ggplot(ab.frame)+geom_density(aes(x=x))
#ggplot(ab.frame)+geom_density(aes(x=x))+geom_density(aes(x=x,colour=type))

# position of the name of data frame
cd.frame <- data.frame(c=a,d=b)
ggplot()+geom_density(data=cd.frame,aes(x=c),size=2)+geom_density(aes(x=d),size=2,colour="red")
ggplot(data=cd.frame)+geom_density(aes(x=c),size=2)+geom_density(aes(x=d),size=2,colour="red")

# Aesthetic
data.aes <- data.frame(x=c(b,b),y=c(b,b+1),type=c(rep("Type1",length(b)),rep("Type2",length(b))))
str(data.aes)
ggplot(data.aes) + geom_point(aes(x=x,y=y,colour=type,shape=type,size=type))
ggplot(data.aes) + geom_point(aes(x=x,y=y,colour=type,shape=type),size=4)
ggplot(data.aes) + geom_point(aes(x=x,y=y,colour=type,shape=type),alpha=0.7)


# Geometry

# CI
a <- rnorm(100)
t.test(a)
(M <- mean(a))
(se <- sd(a)/sqrt(length(a)))
(t <- qt(0.975,df=length(a)-1))
M-t*se
M+t*se
t.test(a)

# error bar
GSE.one <- GSE[1:60,]
data.scatter <- data.frame(mean=c(mean(GSE.one$father_expr),mean(GSE.one$mother_expr)),gender=c("F","M"))
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)
data.scatter$sd <- c(sd(GSE.one$father_expr),sd(GSE.one$mother_expr))
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)+geom_errorbar(aes(x=gender,ymin=mean-sd,ymax=mean+sd),width=0.15)
data.scatter$n <- c(length(GSE.one$father_expr),length(GSE.one$mother_expr))
(data.scatter$se <- data.scatter$sd/sqrt(data.scatter$n))
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)+geom_errorbar(aes(x=gender,ymin=mean-se,ymax=mean+se),width=0.15)
data.scatter$t <- c(qt(0.975,df=length(GSE.one$father_expr)-1),qt(0.975,df=length(GSE.one$mother_expr)-1))
(data.scatter$upper <- data.scatter$mean+data.scatter$t*data.scatter$se)
(data.scatter$lower <- data.scatter$mean-data.scatter$t*data.scatter$se)
ggplot(data.scatter)+geom_point(aes(x=gender,y=mean),size=4)+geom_errorbar(aes(x=gender,ymin=lower,ymax=upper),width=0.15)

data.tri <- data.frame(gender=rep(c("F","M"),each=3),mean=rep(data.scatter$mean,each=3),type=rep(c("SD","SE","CI"),2),max=c(data.scatter$mean[1]+data.scatter$sd[1],data.scatter$mean[1]+data.scatter$se[1],data.scatter$upper[1],data.scatter$mean[2]+data.scatter$sd[2],data.scatter$mean[2]+data.scatter$se[2],data.scatter$upper[2]),min=c(data.scatter$mean[1]-data.scatter$sd[1],data.scatter$mean[1]-data.scatter$se[1],data.scatter$lower[1],data.scatter$mean[2]-data.scatter$sd[2],data.scatter$mean[2]-data.scatter$se[2],data.scatter$lower[2]))
data.tri$type <- factor(data.tri$type,levels=c("SD","SE","CI"))
ggplot(data.tri)+geom_bar(aes(x=gender,y=mean,colour=type),stat="identity",position="dodge",fill="NA")+geom_errorbar(aes(x=gender,ymin=min,ymax=max,colour=type),position=position_dodge(width=0.9),width=0.2)

# boxplot
GSE.one <- GSE[1:60,]
sum(is.na(GSE.one$father_expr))
sum(is.na(GSE.one$mother_expr))
data.box <- data.frame(exp=c(GSE.one$mother_expr,GSE.one$father_expr),type=c(rep("Mother",length(GSE.one$mother_expr)),rep("Father",length(GSE.one$father_expr))))
p1 <- ggplot(data.box)+geom_boxplot(aes(x=type,y=exp))
vp1 <- viewport(x=0.25,y=0.5,width=0.5,height=1)
p2 <- ggplot(data.box)+geom_boxplot(aes(x=type,y=exp),notch=T)
vp2 <- viewport(x=0.75,y=0.5,width=0.5,height=1)
print(p1,vp=vp1)
print(p2,vp=vp2)
# definition whisker
(box<-boxplot.stats(GSE.one$father_expr)$stats)
(IQR <- box[4]-box[2])
(whisker <- 1.5*IQR)
(box1<-boxplot.stats(GSE.one$father_expr, coef = 1.5, do.conf = TRUE, do.out = TRUE)$stats)
max(GSE.one$father_expr[GSE.one$father_expr<=(box[4]+whisker)])
min(GSE.one$father_expr[GSE.one$father_expr>=(box[2]-whisker)])

# lm
str(diamonds)
dia <- diamonds[sample(1:length(diamonds[,1]),1000),]
str(dia)
ggplot(diamonds) + geom_smooth(aes(x=father_expr,y=mother_expr),method="lm")
ggplot(GSE.one)+geom_point(aes(x=mother_expr,y=offspring_expr))+geom_smooth(aes(x=mother_expr,y=offspring_expr),method="lm")
summary(lm(offspring_expr~mother_expr,data=GSE.one))$coefficients
ggplot(GSE.100) + geom_point(aes(x=mother_expr,y=offspring_expr,colour=race),alpha=0.5)+geom_smooth(aes(x=mother_expr,y=offspring_expr,colour=race),method="lm",size=2)
summary(lm(offspring_expr~mother_expr*race,data=GSE.one))$coefficients


# Faceting
ggplot(GSE.sub) + geom_point(aes(x=mother_expr,y=father_expr)) + facet_wrap(~gene)
ggplot(GSE.sub) + geom_point(aes(x=mother_expr,y=father_expr)) + facet_wrap(~gene,scale="free")
ggplot(GSE.sub) + geom_point(aes(x=mother_expr,y=father_expr)) + facet_grid(sex~race)

# transparency
ggplot(GSE.100) + geom_point(aes(x=mother_expr,y=father_expr))
ggplot(GSE.100) + geom_point(aes(x=mother_expr,y=father_expr),alpha=.5)

# position adjustments
GSE.sub <- GSE[1:600,]
GSE.sub$gene <- as.factor(as.character(GSE.sub$gene))
str(GSE.sub)
data <- data.frame(race=c("CEU","CEU","YRI","YRI"),gender=c("S","D","S","D"),exp=c(mean(GSE.sub[GSE.sub$race=="CEU" & GSE.sub$sex=="s","offspring_expr"]),mean(GSE.sub[GSE.sub$race=="CEU" & GSE.sub$sex=="d","offspring_expr"]),mean(GSE.sub[GSE.sub$race=="YRI" & GSE.sub$sex=="s","offspring_expr"]),mean(GSE.sub[GSE.sub$race=="YRI" & GSE.sub$sex=="d","offspring_expr"])))
ggplot(data)+geom_bar(aes(x=race,y=exp,fill=gender),stat="identity",position="dodge")
data <- data.frame(race=c("CEU","CEU","YRI","YRI"),gender=c("S","D","S","D"),count=c(sum(GSE.sub$race=="CEU" & GSE.sub$sex=="s"),sum(GSE.sub$race=="CEU" & GSE.sub$sex=="d"),sum(GSE.sub$race=="YRI" & GSE.sub$sex=="s"),sum(GSE.sub$race=="YRI" & GSE.sub$sex=="d")))
ggplot(data)+geom_bar(aes(x=race,y=count,fill=gender),stat="identity",position="stack")
ggplot(data)+geom_bar(aes(x=race,y=count,fill=gender),stat="identity",position="fill")
ggplot(GSE.10) + geom_point(aes(x=gene,y=offspring_expr))
ggplot(GSE.10) + geom_point(aes(x=gene,y=offspring_expr),position="jitter")

# setting the colour
ggplot(data.aes)+geom_point(aes(x=x,y=y,colour=type),size=4)+scale_colour_manual(values=c("red","black"))

decimal <- c(248,118,109)
(hexa <- as.hexmode(decimal))
# Integer part
(First <- floor(decimal/16))
# Remainder part
(Sec <- decimal%%16)
"#F8766D"
scales::hue_pal()(2)

# Multiple graphs on one page
pdf.out <- "E:/work/test/test.pdf"
pdf(pdf.out)
p1 <- ggplot(GSE.sub)+geom_boxplot(aes(x=sex,y=offspring_expr))
vp1 <- viewport(x=0.25,y=0.75,width=0.5,height=0.5)
print(p1,vp=vp1)
vp2 <- viewport(x=0.5,y=0.25,width=1,height=0.5)
print(p1,vp=vp2)
dev.off()

# width of error bar
data1 <- data.frame(x=1:3,y=1:3,z=c("a","b","c"))
ggplot(data1)+geom_errorbar(aes(x=x,ymin=y-y,ymax=y+y),width=1)
data2 <- data.frame(x=c(10,20,30),y=c(10,20,30))
ggplot(data2)+geom_errorbar(aes(x=x,ymin=y-y,ymax=y+y),width=1)
ggplot(data1)+geom_errorbar(aes(x=z,ymin=y-y,ymax=y+y),width=1)

# coordinate system
pie.data<-data.frame(y=c(1,2),type=c("M","F"))
ggplot(pie.data)+geom_bar(aes(x="",y=y,fill=type),stat="identity")+coord_polar("y")
ggplot(pie.data)+geom_bar(aes(x="",y=y,fill=type),stat="identity",width=1)+coord_polar("y")

A <- c(rnorm(16), rnorm(4, 20))
B <- rnorm(20)
plot(density(A), ylim = c(0, 0.5))
lines(density(B), col ="red")

t.test(A, B)
wilcox.test(A, B)
#it is important to look at the data in figures

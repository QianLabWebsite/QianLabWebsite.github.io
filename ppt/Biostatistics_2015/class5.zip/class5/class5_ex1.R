library(gplots)

setwd("D:/IGDB/courses/SDC/2015/classIV")
GSE6536 <-  read.table("GSE6536_series_matrix_trio_ensembl_avg_list.txt", header = TRUE)
str(GSE6536)

#anova
Expr_Chr <- aov(GSE6536$offspring_expr ~ GSE6536$chrom)
summary(Expr_Chr)
anova(Expr_Chr)
#anova and summary is similar
str(summary(Expr_Chr))

#to look at the data
plot(GSE6536$offspring_expr ~ GSE6536$chrom)
plotmeans(GSE6536$offspring_expr ~ GSE6536$chrom)

#two sample anova is equivalent to t test
Expr_Sex <- aov(GSE6536$offspring_expr ~ GSE6536$sex)
summary(Expr_Sex)
(T <- t.test(GSE6536$offspring_expr[GSE6536$sex == "d"],
       GSE6536$offspring_expr[GSE6536$sex == "s"]))


Expr_Race_Sex <- aov(GSE6536$offspring_expr ~ GSE6536$race + GSE6536$sex)
summary(Expr_Race_Sex)

Expr_Race_Sex_Inter <- aov(GSE6536$offspring_expr ~ GSE6536$race * GSE6536$sex)
summary(Expr_Race_Sex_Inter)
interaction.plot(GSE6536$race, GSE6536$sex, GSE6536$offspring_expr)


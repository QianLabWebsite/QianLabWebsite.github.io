library(tseries)

(x1 <- as.factor(rep(c(0, 1), each = 10)))
(x2 <- as.factor(rep(c(0, 1), time = 10)))

runs.test(x1)
runs.test(x2)


(x3 <- as.factor(sample(x = 0:1, size = 20, replace = T)))

runs.test(x3)

setwd("D:/IGDB/courses/SDC/2015/classV")

#H0: gene orientation is random
#HA: for the sake of sharing proximate cis regulatory elements, 
#gene orientation is not random; rather, it change more frequently than 
#random expectation
Orientation <- read.table("chr-ori.txt", header = T)
str(Orientation)
runs.test(Orientation$ori[Orientation$chr == "A"])

#additional samples?
runs.test(Orientation$ori)

#is it due to a few chromosomes?
(Runs <- tapply(X = Orientation$ori, INDEX = Orientation$chr, FUN = runs.test))
str(Runs)
(SN <- unlist(Runs)[1:16 *5 -4])
(Pval <- unlist(Runs)[1:16 *5 -2])

#meta-analysis Fisher's method
# (Chisq <- -2 * sum(log(as.numeric(Pval))))
# pchisq(q = Chisq, df = 32, lower.tail = F)
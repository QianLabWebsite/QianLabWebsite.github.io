library(lmodel2)
library(ppcor)
library(boot)

#setwd("D:/IGDB/courses/SDC/2015/classIV")
#GSE6536 <-  read.table("GSE6536_series_matrix_trio_ensembl_avg_list.txt", header = TRUE)
#str(GSE6536)

#linear regression: the prediction power
plot(rnorm(30) ~ rnorm(30))
(Lm <- lm(rnorm(30) ~ rnorm(30)))
abline(Lm)
summary(Lm)
str(Lm)

#a second example
A <- rnorm(30)
B <- A + rnorm(30)
plot(A ~ B)
(Lm <- lm(A ~ B))
abline(Lm)

#examination of residues
#plot(lm(A ~ B))

#two different regressions: two different predictions
summary(lm(B ~ A))
summary(lm(A ~ B))


#correlation analysis
plot(rnorm(30), rnorm(30))
cor.test(rnorm(30), rnorm(30))
plot(A * 2 ~ A)
cor.test(A, A * 2)

#a third example
A <- rnorm(10000)
B <- A + rnorm(10000)
plot(B ~ A)
(Cor <- cor.test(A, B))
str(Cor)

# the meaning of r2
(Cor$estimate) ^ 2

B <- 2* A + rnorm(10000)
(Cor <- cor.test(A, B))
(Cor$estimate) ^ 2
#r2 is of central importance

#major axis: perpendicular distance
B <- 10 * (A + rnorm(10000))
plot(B ~ A)
abline(lm(B ~ A))
Lm_t <- lm(A ~ B)
Lm_t$coefficients
Slope <- 1 / Lm_t$coefficients[2]
Intercept <- -Lm_t$coefficients[1] / Lm_t$coefficients[2]
abline(a = Intercept, b = Slope)

Df <- as.data.frame(cbind(B, A))
Lm2 <- lmodel2 (B ~ A, data = Df)
lines(Lm2, "SMA")


#spearman's correlation
A <- rnorm(30)
D <- c(A, 30)
E <- c(-A, 30)
plot(D, E)
cor.test(E, D)
cor.test(E, D, method = "s")

#spearman's correlation may not always work
#introduction to kendall's tau test
D <- c(A, A - 30)
E <- c(A, A + 30)
plot(D, E)
cor.test(E, D)

cor.test(E, D, method = "s")
cor.test(E, D, method = "k")
#the importance of looking at the raw data

#general linear regression
summary(lm(GSE6536$offspring_expr ~ GSE6536$chrom))
summary(aov(GSE6536$offspring_expr ~ GSE6536$chrom))

#multiple regression
summary(lm(GSE6536$offspring_expr ~ GSE6536$sex + GSE6536$race))
summary(lm(GSE6536$offspring_expr ~ GSE6536$sex * GSE6536$race))

#partial correlation
cor(GSE6536[, c("offspring_expr", "father_expr", "mother_expr")])
plot(GSE6536[1:60, c("offspring_expr", "father_expr", "mother_expr")])
cor(GSE6536[1:60, c("offspring_expr", "father_expr", "mother_expr")])
cor.test(GSE6536$mother_expr[1:60], GSE6536$offspring_expr[1:60])
pcor(GSE6536[1:60, c("father_expr", "mother_expr", "offspring_expr")])
pcor(GSE6536[1:60, c("father_expr", "mother_expr", "offspring_expr")], method = "s")

#bootstrap to obtain confidence interval
summary(lm(GSE6536$offspring_expr[1:60] ~ GSE6536$sex[1:60]))
rsq <- function(fomula, data, indices) {
  return(summary(lm(fomula, data = data[indices,]))$r.square)
}
Boot <- boot(data = GSE6536, statistic = rsq,
             R=10, fomula = offspring_expr[1:60] ~ sex[1:60])
Boot
plot(Boot)
boot.ci(Boot)
